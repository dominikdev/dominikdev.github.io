function typingScriptOptions(){

       message = "Your Message Goes Here!"; // Your Message Here
       messageWrapper = document.getElementById('text-wrapper'); // Message Wrapper Here
       
       typingSpeed = 150; //Typing speed in ms
       
}